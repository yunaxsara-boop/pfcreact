import { useNavigate } from "react-router-dom";
import {
  Box, Typography, Button, Container, Grid, Paper,
  Stack, Avatar, List, ListItem, ListItemIcon, ListItemText,
  createTheme, ThemeProvider, CssBaseline, alpha,
} from "@mui/material";
import ArrowForwardIcon            from "@mui/icons-material/ArrowForward";
import SearchOutlinedIcon          from "@mui/icons-material/SearchOutlined";
import PaymentsOutlinedIcon        from "@mui/icons-material/PaymentsOutlined";
import AccountBalanceOutlinedIcon  from "@mui/icons-material/AccountBalanceOutlined";
import GavelOutlinedIcon           from "@mui/icons-material/GavelOutlined";
import LanguageOutlinedIcon        from "@mui/icons-material/LanguageOutlined";
import TaskAltOutlinedIcon         from "@mui/icons-material/TaskAltOutlined";
import EngineeringOutlinedIcon     from "@mui/icons-material/EngineeringOutlined";
import ScienceOutlinedIcon         from "@mui/icons-material/ScienceOutlined";
import GroupsOutlinedIcon          from "@mui/icons-material/GroupsOutlined";
import BusinessOutlinedIcon        from "@mui/icons-material/BusinessOutlined";
import FolderOpenOutlinedIcon      from "@mui/icons-material/FolderOpenOutlined";
import LockOutlinedIcon            from "@mui/icons-material/LockOutlined";
import InfoOutlinedIcon            from "@mui/icons-material/InfoOutlined";
import EmailOutlinedIcon           from "@mui/icons-material/EmailOutlined";
import CheckCircleOutlineIcon      from "@mui/icons-material/CheckCircleOutline";

import { lightTheme } from "../Home";
import { PublicNavbar, PublicBreadcrumb, PublicFooter } from "./PublicLayout";

/* ── Data ── */
const ROLES = [
  {
    icon:<EngineeringOutlinedIcon/>, color:"#E8440A", bg:"#FEF0EB",
    title:"L'Inventeur",
    items:[
      "Préparer et transmettre le dossier complet à la DC R&D (daté, signé, contre accusé de réception)",
      "Renseigner 4 exemplaires du formulaire de requête INAPI, signés par le responsable de structure",
      "Fournir le mémoire descriptif : 2 ex. en français + 1 ex. en arabe",
      "Garder l'invention secrète jusqu'au dépôt officiel à l'INAPI",
      "Peut envoyer les documents par email à la DC R&D en avant-première",
    ],
  },
  {
    icon:<ScienceOutlinedIcon/>, color:"#2563EB", bg:"#EFF6FF",
    title:"Direction Centrale R&D (DC R&D)",
    items:[
      "Réceptionner et déposer toutes les demandes auprès de l'INAPI",
      "Réaliser la recherche d'antériorité dans les 15 jours suivant la réception",
      "Transmettre le dossier au CST pour examen et enrichissement",
      "Assurer le suivi et le paiement de toutes les taxes et annuités",
      "Maintenir le Registre des brevets, dessins et modèles de SONATRACH",
      "Assurer un reporting semestriel à la Direction Générale",
      "Notifier l'inventeur à chaque étape, du dépôt jusqu'à la décision INAPI",
    ],
  },
  {
    icon:<GroupsOutlinedIcon/>, color:"#7C3AED", bg:"#F5F3FF",
    title:"Conseil Scientifique & Technique (CST)",
    items:[
      "Examiner la demande de protection pour enrichissement et amélioration (délai : 1 mois max)",
      "Interpréter les résultats de la recherche d'antériorité réalisée par la DC R&D",
      "Établir un procès-verbal (PV) reprenant ses conclusions et le transmettre à la DC R&D",
      "Signaler tout dysfonctionnement à la DC R&D",
    ],
  },
  {
    icon:<BusinessOutlinedIcon/>, color:"#059669", bg:"#ECFDF5",
    title:"Structures de SONATRACH",
    items:[
      "Élaborer et mettre à jour les conventions de partenariat qui les concernent",
      "Signaler tout dysfonctionnement dans l'application de la procédure à la DC R&D",
      "Veiller à l'application des dispositions de la présente procédure",
    ],
  },
];

const PROCESSUS = [
  { num:"01", icon:<FolderOpenOutlinedIcon/>,        color:"#E8440A", bg:"#FEF0EB",
    title:"Dossier préparé par l'inventeur",
    desc:"L'inventeur prépare le dossier complet et le transmet à la DC R&D, daté et signé, contre accusé de réception sur la lettre d'accompagnement.",
    note:"Envoi anticipé possible : demande.brevet@sonatrach.dz" },
  { num:"02", icon:<SearchOutlinedIcon/>,            color:"#2563EB", bg:"#EFF6FF",
    title:"Recherche d'antériorité",
    desc:"La DC R&D réalise la recherche d'antériorité sur l'invention et établit un rapport dans un délai de 15 jours à compter de la réception du dossier.",
    note:"Si le rapport n'est pas concluant → le dossier est archivé." },
  { num:"03", icon:<GroupsOutlinedIcon/>,            color:"#7C3AED", bg:"#F5F3FF",
    title:"Examen par le CST",
    desc:"Le dossier et le rapport d'antériorité sont transmis au CST de SONATRACH. Le CST examine, enrichit et améliore la demande, puis établit un PV de conclusions.",
    note:"Délai maximum d'examen : 1 mois." },
  { num:"04", icon:<AccountBalanceOutlinedIcon/>,    color:"#059669", bg:"#ECFDF5",
    title:"Dépôt auprès de l'INAPI",
    desc:"La DC R&D dépose la demande directement à l'INAPI dans les 5 jours ouvrables suivant l'approbation par le CST.",
    note:"La DC R&D assure le suivi du dossier jusqu'à la décision finale." },
  { num:"05", icon:<PaymentsOutlinedIcon/>,          color:"#D97706", bg:"#FFFBEB",
    title:"Paiement des taxes",
    desc:"Les taxes et frais de protection sont acquittés par la DC R&D dans le mois suivant le dépôt (délai INAPI : 1 mois calendaire).",
    note:"La 2ème annuité est due 1 mois avant l'expiration des 365 jours du dépôt." },
  { num:"06", icon:<GavelOutlinedIcon/>,             color:"#DC2626", bg:"#FEF2F2",
    title:"Évaluation technique par l'INAPI",
    desc:"L'INAPI évalue techniquement la demande. En cas de résultat positif, l'attestation de brevetage est transmise à la Direction Centrale Juridique, puis copiée à toutes les parties.",
    note:"Si négatif : toutes les parties sont informées et le dossier est archivé." },
  { num:"07", icon:<LanguageOutlinedIcon/>,          color:"#0891B2", bg:"#F0FDFA",
    title:"Protection internationale (PCT)",
    desc:"Si la recherche d'antériorité internationale est concluante, la DC R&D lance une demande PCT via l'INAPI pour couvrir les pays membres du traité.",
    note:"Après avis du CST et lancement par la DC R&D." },
  { num:"08", icon:<TaskAltOutlinedIcon/>,           color:"#16A34A", bg:"#F0FDF4",
    title:"Veille à la mise en exploitation",
    desc:"La DC R&D veille à la mise en exploitation de l'invention durant les 4 années suivant le dépôt, via valorisation interne ou concession de la licence d'exploitation.",
    note:"Conformément à l'article 38 de l'ordonnance n°03-07 du 19 juillet 2003." },
];

/* ── Component ── */
export default function Procedure() {
  const navigate = useNavigate();

  return (
    <ThemeProvider theme={lightTheme}>
      <CssBaseline/>
      <style>{`@import url('https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700;800;900&display=swap');`}</style>

      <PublicNavbar/>
      <PublicBreadcrumb current="Procédure interne"/>

      {/* ── Hero section ── */}
      <Box sx={{ background:"linear-gradient(135deg,#0C0C0C 0%,#1A0800 60%,#0C0C0C 100%)", py:{ xs:7, md:10 }, position:"relative", overflow:"hidden" }}>
        <Box sx={{ position:"absolute", top:"-10%", right:"-5%", width:400, height:400, borderRadius:"50%", background:"radial-gradient(circle,rgba(232,68,10,0.70) 0%,transparent 65%)", filter:"blur(50px)", pointerEvents:"none" }}/>
        <Container maxWidth="lg" sx={{ position:"relative", zIndex:1 }}>
          <Grid container spacing={5} alignItems="center">
            <Grid item xs={12} md={7}>
              <Typography sx={{ fontSize:11, fontWeight:700, color:"#F97316", letterSpacing:"2px", textTransform:"uppercase", mb:1.5 }}>
                Manuel Général d'Organisation · N° 364/DG
              </Typography>
              <Typography variant="h1" sx={{ fontSize:{ xs:30, md:48 }, fontWeight:900, color:"white", letterSpacing:"-2px", lineHeight:1.08, mb:2 }}>
                Procédure interne de<br/>
                <Box component="span" sx={{ background:"linear-gradient(90deg,#F97316,#FBBF24)", WebkitBackgroundClip:"text", WebkitTextFillColor:"transparent" }}>
                  gestion des brevets
                </Box>
              </Typography>
              <Typography sx={{ fontSize:15.5, color:"rgba(255,255,255,0.52)", lineHeight:1.82, mb:4, maxWidth:520 }}>
                De la déclaration de l'inventeur jusqu'au dépôt à l'INAPI et à la mise en exploitation.
                Rôles de la DC R&D, du CST, des structures et de l'inventeur.
              </Typography>
              <Stack direction="row" spacing={2} flexWrap="wrap" useFlexGap>
                <Button variant="contained" color="primary"
                  onClick={() => navigate("/dossier")}
                  endIcon={<ArrowForwardIcon/>}
                  sx={{ px:3.5, py:1.2, fontWeight:700, boxShadow:"0 4px 18px rgba(232,68,10,0.45)" }}
                >Voir le dossier à préparer</Button>
                <Box sx={{ display:"inline-flex", alignItems:"center", gap:1,
                  background:"rgba(255,255,255,0.07)", border:"1px solid rgba(255,255,255,0.12)",
                  borderRadius:"999px", px:2, py:1, backdropFilter:"blur(8px)" }}>
                  <EmailOutlinedIcon sx={{ fontSize:14, color:"#F97316" }}/>
                  <Typography component="a" href="mailto:demande.brevet@sonatrach.dz"
                    sx={{ fontSize:12.5, color:"rgba(255,255,255,0.65)", textDecoration:"none", "&:hover":{ color:"#F97316" } }}>
                    demande.brevet@sonatrach.dz
                  </Typography>
                </Box>
              </Stack>
            </Grid>
            <Grid item xs={12} md={5}>
              {/* Quick info cards */}
              <Stack spacing={2}>
                {[
                  { label:"Délai recherche d'antériorité", value:"15 jours", color:"#F97316" },
                  { label:"Délai examen par le CST",        value:"1 mois max", color:"#8B5CF6" },
                  { label:"Dépôt à l'INAPI après CST",     value:"5 jours ouvrables", color:"#10B981" },
                  { label:"Durée de protection brevet",     value:"20 ans",    color:"#3B82F6" },
                ].map(({ label, value, color }) => (
                  <Paper key={label} sx={{ p:2.2, borderRadius:"12px", background:"rgba(255,255,255,0.06)", backdropFilter:"blur(8px)", border:"1px solid rgba(255,255,255,0.10)" }}>
                    <Stack direction="row" justifyContent="space-between" alignItems="center">
                      <Typography sx={{ fontSize:13.5, color:"rgba(255,255,255,0.60)", fontWeight:500 }}>{label}</Typography>
                      <Typography sx={{ fontSize:15, fontWeight:800, color }}>{value}</Typography>
                    </Stack>
                  </Paper>
                ))}
              </Stack>
            </Grid>
          </Grid>
        </Container>
      </Box>

      {/* ── Rôles ── */}
      <Box sx={{ background:"#F2F2F2", py:9 }}>
        <Container maxWidth="lg">
          <Typography sx={{ fontSize:11, fontWeight:700, color:"#E8440A", letterSpacing:"2px", textTransform:"uppercase", mb:1 }}>
            Organisation
          </Typography>
          <Typography variant="h2" sx={{ fontSize:{ xs:22, md:32 }, letterSpacing:"-1px", color:"#111", mb:5 }}>
            Rôles &amp; Responsabilités
          </Typography>
          <Grid container spacing={3}>
            {ROLES.map(({ icon, color, bg, title, items }) => (
              <Grid item xs={12} sm={6} key={title}>
                <Paper sx={{ p:3, borderRadius:"16px", border:"1px solid #E8E8E8", height:"100%",
                  transition:"all .22s", "&:hover":{ boxShadow:`0 10px 32px ${alpha(color,0.12)}`, transform:"translateY(-3px)" } }}>
                  <Stack direction="row" spacing={2} alignItems="center" mb={2}>
                    <Avatar sx={{ background:bg, color, width:44, height:44, "& svg":{ fontSize:22 } }}>{icon}</Avatar>
                    <Typography sx={{ fontWeight:700, fontSize:15, color:"#111" }}>{title}</Typography>
                  </Stack>
                  <List dense disablePadding>
                    {items.map((item, i) => (
                      <ListItem key={i} disableGutters alignItems="flex-start" sx={{ mb:.6 }}>
                        <ListItemIcon sx={{ minWidth:24, mt:.3 }}>
                          <CheckCircleOutlineIcon sx={{ fontSize:15, color }}/>
                        </ListItemIcon>
                        <ListItemText primary={item} primaryTypographyProps={{ fontSize:13, color:"#555", lineHeight:1.68 }}/>
                      </ListItem>
                    ))}
                  </List>
                </Paper>
              </Grid>
            ))}
          </Grid>
        </Container>
      </Box>

      {/* ── 8 Étapes ── */}
      <Box sx={{ background:"white", py:9, borderTop:"1px solid #EBEBEB" }}>
        <Container maxWidth="lg">
          <Typography sx={{ fontSize:11, fontWeight:700, color:"#E8440A", letterSpacing:"2px", textTransform:"uppercase", mb:1 }}>
            Déroulement
          </Typography>
          <Typography variant="h2" sx={{ fontSize:{ xs:22, md:32 }, letterSpacing:"-1px", color:"#111", mb:5 }}>
            Les 8 étapes du processus
          </Typography>
          <Grid container spacing={2.5}>
            {PROCESSUS.map((s, i) => (
              <Grid item xs={12} sm={6} md={6} lg={3} key={i}>
                <Paper sx={{
                  p:3, borderRadius:"16px", border:"1.5px solid #EBEBEB",
                  height:"100%", position:"relative", overflow:"hidden",
                  transition:"all .25s",
                  "&:hover":{ borderColor:s.color, boxShadow:`0 12px 36px ${alpha(s.color,0.13)}`, transform:"translateY(-4px)" },
                }}>
                  <Typography sx={{ position:"absolute", top:10, right:14, fontSize:54, fontWeight:900, color:"rgba(0,0,0,0.03)", lineHeight:1, userSelect:"none" }}>
                    {s.num}
                  </Typography>
                  <Avatar sx={{ background:s.bg, color:s.color, width:44, height:44, mb:2, "& svg":{ fontSize:21 } }}>{s.icon}</Avatar>
                  <Typography sx={{ fontWeight:700, fontSize:14.5, color:"#111", mb:1, lineHeight:1.35 }}>{s.title}</Typography>
                  <Typography sx={{ fontSize:12.5, color:"#777", lineHeight:1.70, mb:1.5 }}>{s.desc}</Typography>
                  {s.note && (
                    <Box sx={{ display:"flex", alignItems:"flex-start", gap:.8, background:"#F7F7F7", borderRadius:"8px", p:1.2 }}>
                      <InfoOutlinedIcon sx={{ fontSize:14, color:s.color, mt:.15, flexShrink:0 }}/>
                      <Typography sx={{ fontSize:11.5, color:"#666", lineHeight:1.60 }}>{s.note}</Typography>
                    </Box>
                  )}
                </Paper>
              </Grid>
            ))}
          </Grid>

          {/* Confidentialité */}
          <Paper sx={{ mt:4, p:3, borderRadius:"16px", background:"#FEF0EB", border:"1px solid rgba(232,68,10,0.18)" }}>
            <Stack direction="row" spacing={2} alignItems="flex-start">
              <LockOutlinedIcon sx={{ color:"#E8440A", fontSize:22, mt:.2, flexShrink:0 }}/>
              <Box>
                <Typography sx={{ fontWeight:700, fontSize:15, color:"#111", mb:.8 }}>Confidentialité &amp; Droits sur l'invention</Typography>
                <Typography sx={{ fontSize:13.5, color:"#7A2600", lineHeight:1.78 }}>
                  Toutes les parties (inventeur, DC R&D, CST, structures partenaires) sont tenues de garder l'invention <strong>secrète jusqu'au dépôt officiel</strong>.
                  Le droit sur l'invention appartient à <strong>SONATRACH</strong> sauf renonciation expresse — dans ce cas il revient à l'inventeur.
                </Typography>
              </Box>
            </Stack>
          </Paper>
        </Container>
      </Box>

      {/* ── CTA next pages ── */}
      <Box sx={{ background:"#F2F2F2", py:7, borderTop:"1px solid #EBEBEB" }}>
        <Container maxWidth="lg">
          <Grid container spacing={3}>
            {[
              { to:"/dossier", label:"Dossier à préparer →", desc:"Pièces à fournir pour brevet et dessins" },
              { to:"/tarifs",  label:"Tarifs INAPI →",       desc:"Barème officiel par type de déposant" },
            ].map(({ to, label, desc }) => (
              <Grid item xs={12} md={6} key={to}>
                <Paper variant="outlined" onClick={() => navigate(to)} sx={{
                  p:3, borderRadius:"14px", borderColor:"#DEDEDE", cursor:"pointer",
                  display:"flex", justifyContent:"space-between", alignItems:"center",
                  transition:"all .22s",
                  "&:hover":{ borderColor:"#E8440A", background:"#FEF8F5", boxShadow:"0 6px 20px rgba(232,68,10,0.09)" },
                }}>
                  <Box>
                    <Typography sx={{ fontWeight:700, fontSize:15.5, color:"#E8440A" }}>{label}</Typography>
                    <Typography sx={{ fontSize:13, color:"#888" }}>{desc}</Typography>
                  </Box>
                  <ArrowForwardIcon sx={{ color:"#E8440A", fontSize:20 }}/>
                </Paper>
              </Grid>
            ))}
          </Grid>
        </Container>
      </Box>

      <PublicFooter/>
    </ThemeProvider>
  );
}